from django.apps import AppConfig

# Create yours apps here